// AyniteDM browser integration background script. Runs as a Manifest V3 service worker in Chromium browsers
// and as a Manifest V2 background page in Firefox (manifest.firefox.json); the `api` shim covers both.
// - context menu entries and download capture
// - media sniffing: remembers video/audio/HLS/DASH responses per tab for the on-page button and popup
// - quality lists fetched from the desktop app, which runs yt-dlp
// - talks to the desktop app over http://127.0.0.1:<port>

const api = (typeof browser !== "undefined" && browser.runtime) ? browser : chrome;
const action = api.action || api.browserAction;
const sessionStore = (api.storage && api.storage.session) ? api.storage.session : null;
const quiet = (p) => Promise.resolve(p).catch(() => {});

const DEFAULTS = { port: 23571, capture: true, sendCookies: true, overlay: true };
const CAPTURE_EXT = /\.(zip|rar|7z|tar|gz|bz2|xz|iso|exe|msi|msix|apk|dmg|deb|rpm|pdf|epub|mp4|mkv|avi|mov|wmv|webm|mp3|m4a|flac|wav|docx?|xlsx?|pptx?|bin|img|jar)(\?.*)?$/i;
const MEDIA_EXT = /\.(mp4|m4v|webm|mkv|mov|flv|avi|wmv|3gp|mp3|m4a|ogg|opus|wav|flac|aac|m3u8|mpd|f4m)(\?|#|$)/i;
const SEGMENT_EXT = /\.(ts|m4s|m4f|vtt|srt|key|jpe?g|png|gif|webp|svg|woff2?|js|css)(\?|#|$)/i;
const MANIFEST_TYPES = new Set([
  "application/vnd.apple.mpegurl", "application/x-mpegurl", "audio/mpegurl", "audio/x-mpegurl",
  "application/dash+xml", "video/vnd.mpeg.dash.mpd",
]);
// Hosts whose media URLs are chunked/expiring: the page link (handled by yt-dlp) is always better.
const SKIP_MEDIA_HOSTS = ["googlevideo.com", "youtube.com", "ytimg.com", "127.0.0.1", "localhost"];
// Fallback when the app is not running to answer /check.
const KNOWN_VIDEO_HOSTS = [
  "youtube.com", "youtu.be", "youtube-nocookie.com", "vimeo.com", "dailymotion.com", "twitch.tv", "tiktok.com",
  "facebook.com", "fb.watch", "instagram.com", "twitter.com", "x.com", "reddit.com", "streamable.com", "rumble.com",
  "bilibili.com", "soundcloud.com", "ok.ru", "vk.com", "imgur.com", "pinterest.com", "linkedin.com", "archive.org",
  "ted.com", "odysee.com", "bitchute.com", "nicovideo.jp", "twitcasting.tv", "bandcamp.com", "mixcloud.com",
  "9gag.com", "likee.video", "kick.com", "loom.com", "vk.video", "coub.com", "veoh.com", "metacafe.com",
];

const mediaByTab = new Map();       // tabId -> Map(url -> item)
const videoSiteCache = new Map();   // url -> boolean
const formatsCache = new Map();     // url -> { time, data, pending }
const FORMATS_TTL = 10 * 60 * 1000;

// ----------------------------------------------------------------------------- helpers
async function getSettings() {
  const stored = await api.storage.sync.get(DEFAULTS);
  return { ...DEFAULTS, ...stored };
}

function hostOf(url) {
  try { return new URL(url).hostname.toLowerCase(); } catch (e) { return ""; }
}

function hostMatches(host, list) {
  return list.some((h) => host === h || host.endsWith("." + h));
}

function filenameFromUrl(url) {
  try {
    const p = new URL(url).pathname;
    const base = decodeURIComponent(p.split("/").filter(Boolean).pop() || "");
    return base.replace(/[\\/:*?"<>|]/g, "_").slice(0, 150);
  } catch (e) {
    return "";
  }
}

async function cookieHeaderFor(url) {
  try {
    const cookies = await api.cookies.getAll({ url });
    return cookies.map((c) => `${c.name}=${c.value}`).join("; ");
  } catch (e) {
    return "";
  }
}

// Full cookie records (domain/path/flags) so the app can build a real cookie jar for yt-dlp;
// needed for sign-in-only videos (age-restricted, members-only, private).
async function cookieListFor(url) {
  try {
    const cookies = await api.cookies.getAll({ url });
    return cookies.slice(0, 400).map((c) => ({
      name: c.name, value: c.value, domain: c.domain, path: c.path || "/",
      secure: !!c.secure, httpOnly: !!c.httpOnly, expirationDate: c.expirationDate || 0,
    }));
  } catch (e) {
    return [];
  }
}

async function cookiePayload(url) {
  const s = await getSettings();
  if (!s.sendCookies) return {};
  const [cookies, cookie_list] = await Promise.all([cookieHeaderFor(url), cookieListFor(url)]);
  return { cookies, cookie_list };
}

async function appFetch(path, init, timeoutMs) {
  const s = await getSettings();
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs || 4000);
  try {
    return await fetch(`http://127.0.0.1:${s.port}${path}`, { ...(init || {}), signal: ctrl.signal });
  } finally {
    clearTimeout(t);
  }
}

async function getFormats(url, referer) {
  if (!url || !/^https?:/i.test(url)) return { ok: false, error: "bad url" };
  const hit = formatsCache.get(url);
  if (hit && hit.data && Date.now() - hit.time < FORMATS_TTL) return hit.data;
  if (hit && !hit.data && hit.pending) return hit.pending;
  const pending = (async () => {
    try {
      const body = { url, referer: referer || "", ...(await cookiePayload(url)) };
      const res = await appFetch("/formats", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
      }, 45000);
      const data = res.ok ? await res.json() : { ok: false, error: `app replied ${res.status}` };
      formatsCache.set(url, { time: Date.now(), data });
      if (formatsCache.size > 100) formatsCache.delete(formatsCache.keys().next().value);
      return data;
    } catch (e) {
      formatsCache.delete(url);
      return { ok: false, error: "AyniteDM is not running" };
    }
  })();
  formatsCache.set(url, { time: Date.now(), pending, data: null });
  return pending;
}

async function sendToApp(url, referer, filename, mode, preset) {
  const s = await getSettings();
  const payload = { url, referer: referer || "", filename: filename || "", mode: mode || "auto" };
  if (preset && preset.format) {
    for (const k of ["format", "format_label", "format_kind", "audio_codec", "ext"]) if (preset[k]) payload[k] = preset[k];
  }
  Object.assign(payload, await cookiePayload(url));
  try {
    const res = await appFetch("/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }, 6000);
    return res.ok;
  } catch (e) {
    return false;
  }
}

async function isVideoSite(url) {
  if (!url || !/^https?:/i.test(url)) return false;
  if (videoSiteCache.has(url)) return videoSiteCache.get(url);
  let result;
  try {
    const res = await appFetch(`/check?url=${encodeURIComponent(url)}`, {}, 2500);
    const data = res.ok ? await res.json() : null;
    result = data ? !!data.video_site : hostMatches(hostOf(url), KNOWN_VIDEO_HOSTS);
  } catch (e) {
    result = hostMatches(hostOf(url), KNOWN_VIDEO_HOSTS);
  }
  if (videoSiteCache.size > 500) videoSiteCache.clear();
  videoSiteCache.set(url, result);
  return result;
}

function notifyFailure() {
  quiet(action.setBadgeText({ text: "!" }));
  quiet(action.setBadgeBackgroundColor({ color: "#b91c1c" }));
  setTimeout(() => quiet(action.setBadgeText({ text: "" })), 4000);
}

// ----------------------------------------------------------------------------- media store
async function tabMedia(tabId) {
  let map = mediaByTab.get(tabId);
  if (!map) {
    map = new Map();
    if (sessionStore) {
      try {
        const key = `media:${tabId}`;
        const stored = await sessionStore.get(key);
        for (const it of (stored && stored[key]) || []) map.set(it.url, it);
      } catch (e) { /* session storage unavailable */ }
    }
    mediaByTab.set(tabId, map);
  }
  return map;
}

async function listMedia(tabId) {
  const map = await tabMedia(tabId);
  return [...map.values()].sort((a, b) => a.time - b.time);
}

async function persistTab(tabId) {
  if (!sessionStore) return;
  const map = mediaByTab.get(tabId);
  try {
    await sessionStore.set({ [`media:${tabId}`]: map ? [...map.values()] : [] });
  } catch (e) { /* ignore */ }
}

async function clearTab(tabId) {
  mediaByTab.delete(tabId);
  if (sessionStore) { try { await sessionStore.remove(`media:${tabId}`); } catch (e) { /* ignore */ } }
  quiet(action.setBadgeText({ tabId, text: "" }));
}

function updateBadge(tabId, count) {
  quiet(action.setBadgeBackgroundColor({ tabId, color: "#2563eb" }));
  quiet(action.setBadgeText({ tabId, text: count ? String(count) : "" }));
}

async function notifyTab(tabId) {
  const items = await listMedia(tabId);
  updateBadge(tabId, items.length);
  quiet(api.tabs.sendMessage(tabId, { type: "mediaList", items }));
}

function classify(url, ctype) {
  const lower = url.toLowerCase();
  if (MANIFEST_TYPES.has(ctype) || /\.(m3u8|mpd)(\?|#|$)/i.test(lower)) {
    return /dash|\.mpd/.test(ctype + lower) ? "DASH stream" : "HLS stream";
  }
  if (ctype === "video/mp2t" || ctype === "video/iso.segment" || SEGMENT_EXT.test(lower)) return null;
  if (ctype.startsWith("video/")) return "Video";
  if (ctype.startsWith("audio/")) return "Audio";
  if (MEDIA_EXT.test(lower) && !ctype.startsWith("text/")) {
    return /\.(mp3|m4a|ogg|opus|wav|flac|aac)(\?|#|$)/i.test(lower) ? "Audio" : "Video";
  }
  return null;
}

api.webRequest.onHeadersReceived.addListener(
  (d) => {
    if (d.tabId < 0 || !/^https?:/i.test(d.url) || d.statusCode >= 400) return;
    const host = hostOf(d.url);
    if (hostMatches(host, SKIP_MEDIA_HOSTS)) return;
    const headers = {};
    for (const h of d.responseHeaders || []) headers[h.name.toLowerCase()] = h.value || "";
    const ctype = (headers["content-type"] || "").split(";")[0].trim().toLowerCase();
    const kind = classify(d.url, ctype);
    if (!kind) return;
    let size = 0;
    const cr = headers["content-range"];
    const m = cr && cr.match(/\/(\d+)\s*$/);
    if (m) size = parseInt(m[1], 10);
    else if (headers["content-length"]) size = parseInt(headers["content-length"], 10) || 0;
    const isStream = kind.endsWith("stream");
    if (!isStream && size > 0 && size < 200 * 1024) return; // tiny sounds, previews, thumbnails
    (async () => {
      const map = await tabMedia(d.tabId);
      const existing = map.get(d.url);
      if (existing) {
        if (size > existing.size) { existing.size = size; await persistTab(d.tabId); }
        return;
      }
      if (map.size >= 40) return;
      map.set(d.url, {
        url: d.url, kind, size, ctype,
        filename: filenameFromUrl(d.url),
        time: Date.now(),
        pageUrl: d.initiator || d.originUrl || d.documentUrl || "",
      });
      await persistTab(d.tabId);
      await notifyTab(d.tabId);
    })();
  },
  { urls: ["<all_urls>"], types: ["media", "xmlhttprequest", "other", "object", "main_frame", "sub_frame"] },
  ["responseHeaders"]
);

api.webNavigation.onCommitted.addListener((d) => {
  if (d.frameId === 0) clearTab(d.tabId);
});
api.webNavigation.onHistoryStateUpdated.addListener((d) => {
  if (d.frameId === 0) clearTab(d.tabId);
});
api.tabs.onRemoved.addListener((tabId) => clearTab(tabId));

// ----------------------------------------------------------------------------- context menus
function createMenus() {
  quiet(api.contextMenus.removeAll()).then(() => {
    api.contextMenus.create({
      id: "aynitedm-link",
      title: "Download with AyniteDM",
      contexts: ["link", "video", "audio", "image"],
    });
    api.contextMenus.create({
      id: "aynitedm-page",
      title: "Download video from this page with AyniteDM",
      contexts: ["page", "frame"],
    });
    api.contextMenus.create({
      id: "aynitedm-grab",
      title: "Download all links on this page with AyniteDM",
      contexts: ["page", "frame", "selection"],
    });
  });
}

// Ask the page's content script for every link/media element (works for JavaScript-built pages, unlike
// fetching the HTML again) and hand the list to the app's grabber window.
async function grabTab(tabId, pageUrl) {
  let collected = { links: [], title: "" };
  try {
    collected = (await api.tabs.sendMessage(tabId, { type: "collectLinks" }, { frameId: 0 })) || collected;
  } catch (e) {
    /* no content script (e.g. browser-internal page): the app will fetch the page itself */
  }
  try {
    const res = await appFetch("/grab", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ page: pageUrl, title: collected.title || "", links: collected.links || [],
        ...(await cookiePayload(pageUrl)) }),
    }, 8000);
    return res.ok;
  } catch (e) {
    return false;
  }
}
api.runtime.onInstalled.addListener(createMenus);
if (api.runtime.onStartup) api.runtime.onStartup.addListener(createMenus);

api.contextMenus.onClicked.addListener(async (info, tab) => {
  let url = "";
  let mode = "auto";
  if (info.menuItemId === "aynitedm-link") url = info.linkUrl || info.srcUrl || "";
  if (info.menuItemId === "aynitedm-page") {
    url = info.frameUrl || info.pageUrl || (tab && tab.url) || "";
    mode = "video";
  }
  if (info.menuItemId === "aynitedm-grab") {
    const pageUrl = info.pageUrl || (tab && tab.url) || "";
    if (tab && /^https?:/i.test(pageUrl) && !(await grabTab(tab.id, pageUrl))) notifyFailure();
    return;
  }
  if (!url || !/^(https?|ftps?|sftp):|^magnet:/i.test(url)) return;
  const ok = await sendToApp(url, (tab && tab.url) || info.pageUrl || "", "", mode);
  if (!ok) notifyFailure();
});

// ----------------------------------------------------------------------------- download capture
api.downloads.onCreated.addListener(async (item) => {
  const s = await getSettings();
  if (!s.capture) return;
  const url = item.finalUrl || item.url || "";
  if (!/^https?:/i.test(url)) return; // blob:, data:, file: cannot be fetched by the app
  const looksLikeFile = CAPTURE_EXT.test(url) || CAPTURE_EXT.test(item.filename || "") ||
    (item.mime && item.mime !== "text/html" && item.mime !== "");
  if (!looksLikeFile) return;
  const filename = item.filename ? item.filename.split(/[\\/]/).pop() : "";
  const ok = await sendToApp(url, item.referrer || "", filename, "file");
  if (ok) {
    try {
      await api.downloads.cancel(item.id);
      await api.downloads.erase({ id: item.id });
    } catch (e) {
      /* already finished or cancelled */
    }
  } else {
    notifyFailure();
  }
});

// ----------------------------------------------------------------------------- messages
api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return false;

  if (msg.type === "ping") {
    (async () => {
      try {
        const res = await appFetch("/ping", {}, 2500);
        sendResponse({ ok: res.ok, info: res.ok ? await res.json() : null });
      } catch (e) {
        sendResponse({ ok: false });
      }
    })();
    return true;
  }

  if (msg.type === "send") {
    sendToApp(msg.url, msg.referer || "", msg.filename || "", msg.mode || "auto", msg.preset || null)
      .then((ok) => { if (!ok) notifyFailure(); sendResponse({ ok }); });
    return true;
  }

  if (msg.type === "getFormats") {
    getFormats(msg.url, msg.referer || "").then((data) => sendResponse(data));
    return true;
  }

  if (msg.type === "grabPage") {
    grabTab(msg.tabId, msg.url).then((ok) => { if (!ok) notifyFailure(); sendResponse({ ok }); });
    return true;
  }

  if (msg.type === "getContext") {
    // from a content script: everything the overlay needs to know about its tab/frame
    (async () => {
      const tab = sender.tab;
      const tabId = tab ? tab.id : -1;
      const tabUrl = (tab && tab.url) || "";
      const frameUrl = sender.url || "";
      const s = await getSettings();
      const [tabIsVideoSite, frameIsVideoSite, media] = await Promise.all([
        isVideoSite(tabUrl),
        frameUrl && frameUrl !== tabUrl ? isVideoSite(frameUrl) : Promise.resolve(false),
        tabId >= 0 ? listMedia(tabId) : Promise.resolve([]),
      ]);
      sendResponse({ tabUrl, frameUrl, tabIsVideoSite, frameIsVideoSite: frameUrl === tabUrl ? tabIsVideoSite : frameIsVideoSite,
        media, overlay: s.overlay !== false });
    })();
    return true;
  }

  if (msg.type === "getMedia") {
    (async () => {
      const tabId = msg.tabId;
      const media = tabId >= 0 ? await listMedia(tabId) : [];
      const videoSite = msg.url ? await isVideoSite(msg.url) : false;
      sendResponse({ media, videoSite });
    })();
    return true;
  }

  if (msg.type === "isVideoSite") {
    isVideoSite(msg.url).then((v) => sendResponse({ videoSite: v }));
    return true;
  }
  return false;
});
