const api = (typeof browser !== "undefined" && browser.runtime) ? browser : chrome;
const DEFAULTS = { port: 23571, capture: true, sendCookies: true, overlay: true };
const $ = (id) => document.getElementById(id);
let activeTab = null;

function humanSize(n) {
  if (!n) return "";
  const u = ["B", "KB", "MB", "GB"];
  let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return `${n < 10 ? n.toFixed(1) : Math.round(n)} ${u[i]}`;
}

function qualityLabel(q) {
  const m = /^(\d+p\d*)\s+MP4/.exec(q.label || "");
  if (m) return `MP4 ${m[1]}`;
  if (/Audio only - M4A/.test(q.label)) return "Audio only (M4A)";
  if (/Audio only - MP3/.test(q.label)) return "Audio only (MP3)";
  return (q.label || "").replace(/\s*\(~.*\)$/, "");
}

async function load() {
  const s = { ...DEFAULTS, ...(await api.storage.sync.get(DEFAULTS)) };
  $("overlay").checked = s.overlay !== false;
  $("capture").checked = !!s.capture;
  $("sendCookies").checked = !!s.sendCookies;
  $("port").value = s.port;
  [activeTab] = await api.tabs.query({ active: true, currentWindow: true });
  ping();
  loadMedia();
}

function save() {
  api.storage.sync.set({
    overlay: $("overlay").checked,
    capture: $("capture").checked,
    sendCookies: $("sendCookies").checked,
    port: parseInt($("port").value, 10) || DEFAULTS.port,
  });
}

function setStatus(text, ok) {
  const el = $("status");
  el.className = ok ? "status ok" : "status bad";
  el.textContent = text;
}

function ping() {
  chrome.runtime.sendMessage({ type: "ping" }, (res) => {
    if (res && res.ok) setStatus(`Connected to ${res.info.app} ${res.info.version}`, true);
    else setStatus("AyniteDM is not running (or the port is wrong).", false);
  });
}

function send(url, mode, filename, preset) {
  chrome.runtime.sendMessage({ type: "send", url, referer: (activeTab && activeTab.url) || "", filename: filename || "", mode, preset: preset || null },
    (res) => setStatus(res && res.ok ? "Sent to AyniteDM." : "Could not reach AyniteDM.", !!(res && res.ok)));
}

function loadQualities(url) {
  const box = $("qualities");
  box.innerHTML = "";
  const note = document.createElement("div");
  note.className = "empty";
  note.textContent = "Loading quality options...";
  box.appendChild(note);
  chrome.runtime.sendMessage({ type: "getFormats", url, referer: url }, (res) => {
    box.innerHTML = "";
    if (!res || !res.ok) {
      const d = document.createElement("div");
      d.className = "empty";
      d.textContent = res && res.error ? `Quality list unavailable: ${res.error}` : "Quality list unavailable.";
      box.appendChild(d);
      return;
    }
    if (res.title) {
      const t = document.createElement("div");
      t.className = "empty";
      t.style.fontWeight = "600";
      t.textContent = res.title;
      box.appendChild(t);
    }
    for (const q of res.qualities || []) {
      const row = document.createElement("div");
      row.className = "item";
      const info = document.createElement("div");
      info.className = "info";
      const b = document.createElement("b");
      b.textContent = qualityLabel(q);
      const s = document.createElement("small");
      s.textContent = q.size ? `~${humanSize(q.size)}` : (q.kind === "audio" ? "audio" : "");
      info.appendChild(b);
      info.appendChild(s);
      const btn = document.createElement("button");
      btn.textContent = "Download";
      btn.addEventListener("click", () => send(url, "video", "", { format: q.selector, format_label: q.label,
        format_kind: q.kind, audio_codec: q.audio_codec || "", ext: q.ext || "" }));
      row.appendChild(info);
      row.appendChild(btn);
      box.appendChild(row);
    }
  });
}

function loadMedia() {
  if (!activeTab) return;
  chrome.runtime.sendMessage({ type: "getMedia", tabId: activeTab.id, url: activeTab.url || "" }, (res) => {
    const box = $("media");
    box.innerHTML = "";
    const items = (res && res.media) || [];
    const videoSite = !!(res && res.videoSite);
    $("sendTab").textContent = videoSite ? "Download video from this page (supported site)" : "Download video from this page";
    if (videoSite && activeTab.url) loadQualities(activeTab.url);
    if (!items.length) {
      const d = document.createElement("div");
      d.className = "empty";
      d.textContent = "Nothing detected yet. Play the video and reopen this popup.";
      box.appendChild(d);
      return;
    }
    for (const m of items.slice().reverse()) {
      const row = document.createElement("div");
      row.className = "item";
      const info = document.createElement("div");
      info.className = "info";
      const b = document.createElement("b");
      b.textContent = m.filename || m.url;
      b.title = m.url;
      const s = document.createElement("small");
      s.textContent = `${m.kind}${m.size ? " · " + humanSize(m.size) : ""}`;
      info.appendChild(b);
      info.appendChild(s);
      const btn = document.createElement("button");
      btn.textContent = "Download";
      btn.addEventListener("click", () => send(m.url, /stream/.test(m.kind) ? "video" : "auto", ""));
      row.appendChild(info);
      row.appendChild(btn);
      box.appendChild(row);
    }
  });
}

$("overlay").addEventListener("change", save);
$("capture").addEventListener("change", save);
$("sendCookies").addEventListener("change", save);
$("port").addEventListener("change", () => { save(); setTimeout(ping, 200); });
$("sendTab").addEventListener("click", () => {
  if (!activeTab || !activeTab.url || !/^https?:/i.test(activeTab.url)) return;
  send(activeTab.url, "video", "");
});
$("grabTab").addEventListener("click", () => {
  if (!activeTab || !activeTab.url || !/^https?:/i.test(activeTab.url)) return;
  chrome.runtime.sendMessage({ type: "grabPage", tabId: activeTab.id, url: activeTab.url }, (res) =>
    setStatus(res && res.ok ? "Links sent to AyniteDM's grabber." : "Could not reach AyniteDM.", !!(res && res.ok)));
});

load();
