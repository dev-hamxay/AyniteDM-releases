// ADM content script: shows a floating "Download this video" panel over any <video> player on hover,
// like IDM's download button. The dropdown lists the real quality options for the page (fetched from the
// app, which runs yt-dlp), plus the player's direct media file and any streams sniffed by the service worker.
(() => {
  if (window.__admOverlay) return;
  window.__admOverlay = true;

  const PANEL_W = 200;
  const MENU_W = 320;
  const MIN_W = 180, MIN_H = 100;
  let ctx = null;            // { tabUrl, frameUrl, tabIsVideoSite, frameIsVideoSite, media, overlay }
  let media = [];
  const videos = new Set();
  const dismissed = new WeakSet();
  let host, panel, mainLabel, badge, menu, toast;
  let currentVideo = null;
  let hideTimer = null;
  let menuOpen = false;
  let lastMove = 0;
  let lastX = -1, lastY = -1;  // last pointer position, to find the video under it after a scroll
  let scrollTimer = null;
  let lastHref = location.href;
  // quality options for the page link: { url, status: "idle"|"loading"|"ready"|"error", title, qualities, error }
  let formats = { url: "", status: "idle", title: "", qualities: [], error: "" };

  const isHttp = (u) => /^https?:\/\//i.test(u || "");

  function humanSize(n) {
    if (!n) return "";
    const u = ["B", "KB", "MB", "GB"];
    let i = 0;
    while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
    return `${n < 10 ? n.toFixed(1) : Math.round(n)} ${u[i]}`;
  }

  function extOf(url) {
    try {
      const m = new URL(url).pathname.match(/\.([a-z0-9]{2,5})$/i);
      return m ? m[1].toLowerCase() : "";
    } catch (e) { return ""; }
  }

  function basename(url) {
    try {
      return decodeURIComponent(new URL(url).pathname.split("/").filter(Boolean).pop() || "");
    } catch (e) { return ""; }
  }

  function pageTitle() {
    let t = document.title || "";
    t = t.replace(/\s*[-|•·]\s*(YouTube|Vimeo|Dailymotion|Twitch|TikTok|Facebook|X|Twitter)\s*$/i, "");
    return t.replace(/[\\/:*?"<>|]/g, "_").replace(/\s+/g, " ").trim().slice(0, 120) || "video";
  }

  function suggestedName(url, kind) {
    const base = basename(url);
    const ext = extOf(url);
    const generic = !base || base.length < 5 || /^(video|index|master|playlist|manifest|media|stream|file|download|chunklist|init)/i.test(base) ||
      /^[a-f0-9-]{16,}/i.test(base) || /^\d+$/.test(base.replace(/\.\w+$/, ""));
    if (!generic && ext && !/^(m3u8|mpd|f4m)$/.test(ext)) return base;
    const audio = kind === "Audio";
    const outExt = (!ext || /^(m3u8|mpd|f4m)$/.test(ext)) ? (audio ? "m4a" : "mp4") : ext;
    return `${pageTitle()}.${outExt}`;
  }

  // GitHub signs README video addresses for five minutes; the attachment address behind them stays valid and
  // redirects to a freshly signed copy (background.js lists sniffed files under the same address).
  function stableSrc(url) {
    const m = /^https:\/\/private-user-images\.githubusercontent\.com\/\d+\/\d+-([0-9a-f]{8}-[0-9a-f-]{27})\.\w+/i.exec(url || "");
    return m ? `https://github.com/user-attachments/assets/${m[1]}` : url;
  }

  // The file name shown with a player, when the page shows one (GitHub titles each README video's box with it).
  function shownName(video) {
    const box = video && video.closest("details");
    const summary = box && box.querySelector("summary");
    const text = summary ? summary.textContent.trim() : "";
    return /^[^\\/:*?"<>|]{1,150}\.(mp4|m4v|webm|mov|mkv|ogv|mp3|m4a|ogg|opus|wav|flac)$/i.test(text) ? text : "";
  }

  // ---------------------------------------------------------------- candidates
  // On feeds (Facebook, Instagram, X) the page address is not the video's own address; the post around the
  // hovered player carries a link to it, which the app's video-site support can handle.
  const POST_LINK = /\/(videos|reel|reels|watch|p|status)\/|\/watch\/?\?v=|\/video\.php\?v=/i;

  function postLinkFor(video) {
    if (!video) return "";
    let node = video;
    for (let depth = 0; node && depth < 12; depth++) {
      const scope = node.matches && node.matches("article, [role='article'], [data-pagelet], main") ? node : null;
      if (scope || depth === 11) {
        const root = scope || node;
        // without a post around the player, a wide area of a page with several videos would hand every one of
        // them the same link
        if (!scope && root.querySelectorAll("video").length > 1) return "";
        for (const a of root.querySelectorAll("a[href]")) {
          const href = a.href || "";
          if (/\/(blob|raw|tree)\/|\.(mp4|m4v|webm|mov|mkv|gif|png|jpe?g)(\?|#|$)/i.test(href)) continue;   // files, not posts
          if (isHttp(href) && POST_LINK.test(href) && hostOf(href).endsWith(location.hostname.replace(/^www\./, ""))) return href.split("#")[0];
        }
        if (scope) return "";
      }
      node = node.parentElement;
    }
    return "";
  }

  // Feeds that play many videos under one page address (TikTok's For You, YouTube Shorts and hover previews):
  // the link to the hovered video comes from the player's own surroundings, so after scrolling to the next
  // video the previous one is never sent.
  function feedVideoLink(video) {
    if (!video) return "";
    const host = location.hostname;
    if (/(^|\.)tiktok\.com$/i.test(host)) {
      const wrap = video.closest("[id^='xgwrapper-']");          // xgwrapper-<index>-<video id>
      const id = wrap && (wrap.id.match(/-(\d{8,})$/) || [])[1];
      if (id) {
        const item = wrap.closest("article");
        const author = item && item.querySelector("a[href^='/@']");
        const user = author ? author.getAttribute("href").split(/[/?#]/)[1] : "@";   // TikTok redirects /@/video/<id>
        return `https://www.tiktok.com/${user}/video/${id}`;
      }
      const tile = video.closest("a[href*='/video/']");          // profile and search grids
      return tile ? tile.href.split(/[?#]/)[0] : "";
    }
    if (/(^|\.)youtube\.com$/i.test(host)) {
      if (video.closest("ytd-reel-video-renderer") && /^\/shorts\/[\w-]{11}/.test(location.pathname)) {
        return location.origin + location.pathname;
      }
      if (video.closest("ytd-miniplayer, ytd-miniplayer-player-container")) {
        // the mini-player keeps playing while you browse; its own links are end-screen suggestions
        const flexy = document.querySelector("ytd-watch-flexy[video-id]");
        const id = flexy && flexy.getAttribute("video-id");
        return id ? `https://www.youtube.com/watch?v=${id}` : "";
      }
      // the watch page's own player is the page address; every other player (hover previews, Shorts shelves,
      // channel trailers, whatever layout YouTube is testing) takes the nearest video link around it
      if (video.closest("#movie_player") && !video.closest("#inline-preview-player, ytd-video-preview")) return "";
      let node = video.parentElement;
      for (let depth = 0; node && depth < 14; depth++, node = node.parentElement) {
        const a = node.querySelector("a[href*='/watch?v='], a[href*='/shorts/']");
        if (!a) continue;
        const u = new URL(a.href);
        const v = u.searchParams.get("v");
        return v ? `${u.origin}/watch?v=${v}` : u.origin + u.pathname;
      }
      return "";
    }
    if (/(^|\.)facebook\.com$/i.test(host)) {
      // every Facebook player (feed, Watch, Reels, video pages) sits in a [data-video-id] box
      const holder = video.closest("[data-video-id]");
      const id = holder && holder.getAttribute("data-video-id");
      if (id && /^\d+$/.test(id)) {
        return /^\/reels?\//.test(location.pathname) ? `https://www.facebook.com/reel/${id}` : `https://www.facebook.com/watch/?v=${id}`;
      }
      return "";
    }
    // grids that play a preview inside the tile's own link (Instagram explore and profiles, and similar)
    const tile = video.closest("a[href]");
    if (tile && isHttp(tile.href) && POST_LINK.test(tile.href) && hostOf(tile.href).endsWith(host.replace(/^www\./, ""))) {
      return tile.href.split("#")[0];
    }
    return "";
  }

  function pageCandidate() {
    if (!ctx) return null;
    const inFrame = window.top !== window;
    const own = feedVideoLink(currentVideo);
    if (own) {
      return { label: "This video", sub: "best quality, via site support", url: own, mode: "video", filename: "" };
    }
    // A page that lists many videos (home feed, channel, profile, search) is never "this video": its address
    // would queue the whole page. Its players are identified above or by their post link below.
    if (ctx.frameIsVideoSite && !ctx.frameIsListing && isHttp(location.href)) {
      return { label: "This video page", sub: "best quality, via site support", url: location.href, mode: "video", filename: "" };
    }
    if (inFrame && ctx.tabIsVideoSite && !ctx.tabIsListing && isHttp(ctx.tabUrl)) {
      return { label: "This video page", sub: "best quality, via site support", url: ctx.tabUrl, mode: "video", filename: "" };
    }
    const post = postLinkFor(currentVideo);
    if (post) {
      return { label: "This video", sub: "best quality, via site support", url: post, mode: "video", filename: "" };
    }
    return null;
  }

  function otherCandidates() {
    const list = [];
    const seen = new Set();
    const push = (c) => { if (c.url && isHttp(c.url) && !seen.has(c.url)) { seen.add(c.url); list.push(c); } };
    const srcsOf = (v) => [v.currentSrc, v.src, ...[...v.querySelectorAll("source[src]")].map((x) => x.src)]
      .filter(isHttp).map(stableSrc);
    if (currentVideo) {
      const named = shownName(currentVideo);
      for (const src of srcsOf(currentVideo)) {
        const name = named || suggestedName(src, "Video");
        push({ label: `Video file (${extOf(name) || extOf(src) || "direct"})`, sub: (named || basename(src)).slice(0, 40), url: src,
          mode: "auto", filename: name });
      }
    }
    // Files that belong to another player on the page (a README or article with many videos) are not offered
    // for this one.
    const elsewhere = new Set();
    if (currentVideo) {
      for (const v of document.querySelectorAll("video, audio")) {
        if (v !== currentVideo) for (const s of srcsOf(v)) elsewhere.add(s);
      }
    }
    for (const m of media) {
      if (elsewhere.has(m.url)) continue;
      const stream = /stream/.test(m.kind);
      push({ label: `${m.kind}: ${(m.filename || basename(m.url) || m.url).slice(0, 40)}`, sub: stream ? "adaptive stream" : humanSize(m.size),
        url: m.url, mode: stream ? "video" : "auto", filename: suggestedName(m.url, m.kind) });
    }
    return list;
  }

  function candidates() {
    const page = pageCandidate();
    const others = otherCandidates().filter((c) => !page || c.url !== page.url);
    return page ? [page, ...others] : others;
  }

  // ---------------------------------------------------------------- quality options (from the app)
  // start: the person opened the quality list, so a closed ADM is started. Hovering a video never does that.
  function loadFormats(url, start) {
    if (formats.url === url && formats.status !== "idle" && formats.status !== "error") return;
    formats = { url, status: "loading", title: "", qualities: [], error: "" };
    try {
      chrome.runtime.sendMessage({ type: "getFormats", url, referer: location.href, start: !!start }, (res) => {
        if (formats.url !== url) return;   // a newer video was hovered meanwhile
        if (chrome.runtime.lastError || !res) {
          formats = { url, status: "error", title: "", qualities: [], error: "ADM could not be started" };
        } else if (res.ok) {
          formats = { url, status: "ready", title: res.title || "", qualities: res.qualities || [], error: "",
            live: !!res.is_live };
        } else {
          formats = { url, status: "error", title: "", qualities: [], error: res.error || "could not read formats" };
        }
        if (menuOpen) renderMenu();
      });
    } catch (e) {
      formats = { url, status: "error", title: "", qualities: [], error: "extension reloaded; refresh the page" };
    }
  }

  function qualityLabel(q) {
    // "1080p60 MP4  (~120 MB)" -> "MP4 1080p60" + size as the sub line
    const m = /^(\d+p\d*)\s+MP4/.exec(q.label || "");
    if (m) return `MP4  ${m[1]}`;
    if (/Audio only - M4A/.test(q.label)) return "Audio only  M4A";
    if (/Audio only - MP3/.test(q.label)) return "Audio only  MP3";
    return (q.label || "").replace(/\s*\(~.*\)$/, "");
  }

  // ---------------------------------------------------------------- UI
  function buildUI() {
    host = document.createElement("adm-overlay");
    host.style.cssText = "all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;";
    const root = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = `
      :host { all: initial; }
      .panel { position: fixed; display: none; z-index: 2147483647; width: ${PANEL_W}px; box-sizing: border-box;
        font: 13px/1.25 system-ui, "Segoe UI", Arial, sans-serif; color: #fff; background: rgba(15,23,42,.94);
        border-radius: 8px; box-shadow: 0 6px 20px rgba(0,0,0,.4); user-select: none; -webkit-user-select: none; }
      .row { display: flex; align-items: stretch; }
      .main { flex: 1; display: flex; align-items: center; gap: 8px; padding: 9px 10px; cursor: pointer;
        border-radius: 8px 0 0 8px; min-width: 0; }
      .main:hover { background: #2563eb; }
      .panel.protected .main, .panel.protected .main:hover { background: #64748b; cursor: help; }
      .main img { width: 18px; height: 18px; flex: none; }
      .main span { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-weight: 600; }
      .arrow { display: flex; align-items: center; padding: 0 10px; border-left: 1px solid rgba(255,255,255,.18);
        cursor: pointer; border-radius: 0 8px 8px 0; font-size: 11px; }
      .arrow:hover { background: #2563eb; }
      .badge { background: #ef4444; border-radius: 10px; font-size: 10px; padding: 1px 5px; margin-left: 4px; display: none; }
      .close { position: absolute; top: -7px; right: -7px; width: 16px; height: 16px; border-radius: 50%; background: #475569;
        color: #fff; font-size: 11px; line-height: 16px; text-align: center; cursor: pointer; display: none; }
      .panel:hover .close { display: block; }
      .menu { display: none; max-height: 300px; overflow-y: auto; border-top: 1px solid rgba(255,255,255,.15); width: ${MENU_W}px;
        margin-left: ${PANEL_W - MENU_W}px; background: rgba(15,23,42,.97); border-radius: 8px 0 8px 8px; }
      .menu.open { display: block; }
      .head { padding: 7px 10px 4px; font-size: 11px; color: #94a3b8; text-transform: uppercase; letter-spacing: .04em;
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .title { padding: 2px 10px 6px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .item { padding: 7px 10px; cursor: pointer; display: flex; align-items: center; justify-content: space-between; gap: 10px; }
      .item:hover { background: #2563eb; }
      .item b { font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .item small { opacity: .75; font-size: 11px; white-space: nowrap; flex: none; }
      .item.col { flex-direction: column; align-items: stretch; gap: 2px; }
      .note { padding: 8px 10px; font-size: 12px; color: #cbd5e1; }
      .sep { border-top: 1px solid rgba(255,255,255,.12); margin: 4px 0; }
      .toast { position: fixed; display: none; padding: 8px 12px; border-radius: 6px; background: rgba(15,23,42,.94); color: #fff;
        font: 12px system-ui, "Segoe UI", Arial, sans-serif; z-index: 2147483647; box-shadow: 0 4px 14px rgba(0,0,0,.35); }
    `;
    root.appendChild(style);
    panel = document.createElement("div");
    panel.className = "panel";
    panel.innerHTML = `
      <div class="row">
        <div class="main"><img alt=""><span>Download this video</span><i class="badge"></i></div>
        <div class="arrow">&#9660;</div>
      </div>
      <div class="menu"></div>
      <div class="close" title="Hide for this video">&times;</div>`;
    root.appendChild(panel);
    toast = document.createElement("div");
    toast.className = "toast";
    root.appendChild(toast);
    try { panel.querySelector("img").src = chrome.runtime.getURL("icons/32.png"); } catch (e) { /* ignore */ }
    mainLabel = panel.querySelector(".main span");
    badge = panel.querySelector(".badge");
    menu = panel.querySelector(".menu");

    panel.querySelector(".main").addEventListener("click", (e) => {
      e.stopPropagation();
      retarget(e.clientX, e.clientY);
      const c = candidates();
      if (c.length) sendCandidate(c[0]);
      else if (protectedMode && !menuOpen) toggleMenu();
    });
    panel.querySelector(".arrow").addEventListener("click", (e) => {
      e.stopPropagation();
      if (!menuOpen) retarget(e.clientX, e.clientY);
      toggleMenu();
    });
    panel.querySelector(".close").addEventListener("click", (e) => {
      e.stopPropagation();
      if (currentVideo) dismissed.add(currentVideo);
      hideNow();
    });
    panel.addEventListener("mouseenter", () => clearTimeout(hideTimer));
    panel.addEventListener("mouseleave", () => { if (!menuOpen) scheduleHide(); });
    for (const ev of ["mousedown", "mouseup", "click", "dblclick", "keydown", "wheel", "contextmenu"]) {
      panel.addEventListener(ev, (e) => e.stopPropagation());
    }
    (document.body || document.documentElement).appendChild(host);
  }

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }

  function renderMenu() {
    menu.innerHTML = "";
    if (protectedMode) {
      menu.appendChild(el("div", "head", "This video is protected"));
      menu.appendChild(el("div", "note", "This service encrypts its videos (DRM) and the browser only decrypts them inside a "
        + "locked player, so no download manager can save them. ADM works with YouTube and thousands of other sites."));
      return;
    }
    const page = pageCandidate();
    if (page) {
      if (formats.url !== page.url) loadFormats(page.url, true);
      menu.appendChild(el("div", "head", "Download this video as"));
      if (formats.status === "ready" && formats.title) menu.appendChild(el("div", "title", formats.title));
      if (formats.status === "ready" && formats.live) {
        menu.appendChild(el("div", "note", "Live broadcast: recorded from now until you press Stop in ADM"));
      }
      if (formats.status === "loading" || formats.status === "idle") {
        menu.appendChild(el("div", "note", "Loading quality options from ADM..."));
      } else if (formats.status === "error") {
        menu.appendChild(el("div", "note", `Quality list unavailable (${formats.error}).`));
        const it = el("div", "item");
        it.appendChild(el("b", "", "Download with default quality"));
        it.addEventListener("click", (e) => { e.stopPropagation(); sendCandidate(page); });
        menu.appendChild(it);
      } else {
        for (const q of formats.qualities) {
          const it = el("div", "item");
          it.appendChild(el("b", "", qualityLabel(q)));
          it.appendChild(el("small", "", q.size ? `~${humanSize(q.size)}` : (q.kind === "audio" ? "audio" : "")));
          it.title = q.label;
          it.addEventListener("click", (e) => {
            e.stopPropagation();
            sendCandidate({ ...page, preset: { format: q.selector, format_label: q.label, format_kind: q.kind,
              audio_codec: q.audio_codec || "", ext: q.ext || "" } });
          });
          menu.appendChild(it);
        }
      }
    }
    const others = otherCandidates().filter((c) => !page || c.url !== page.url);
    if (others.length) {
      if (page) menu.appendChild(el("div", "sep"));
      menu.appendChild(el("div", "head", page ? "Other media on this page" : "Media on this page"));
      for (const cand of others) {
        const it = el("div", "item col");
        it.appendChild(el("b", "", cand.label));
        it.appendChild(el("small", "", cand.sub || cand.url));
        it.title = cand.url;
        it.addEventListener("click", (e) => { e.stopPropagation(); sendCandidate(cand); });
        menu.appendChild(it);
      }
    }
  }

  function refreshPanel() {
    const c = candidates();
    const n = c.length;
    protectedMode = n === 0 && isProtected(currentVideo);
    panel.classList.toggle("protected", protectedMode);
    if (n === 0 && !protectedMode) { hideNow(); return false; }
    if (protectedMode) {
      mainLabel.textContent = "Protected video";
      badge.style.display = "none";
      if (menuOpen) renderMenu();
      return true;
    }
    const first = c[0];
    mainLabel.textContent = first.mode === "video" || /Video|stream/i.test(first.label) ? "Download this video" : "Download this file";
    badge.style.display = n > 1 ? "inline-block" : "none";
    badge.textContent = String(n);
    const page = pageCandidate();
    if (page) loadFormats(page.url);   // prefetch so the dropdown is instant
    if (menuOpen) renderMenu();
    return true;
  }

  function toggleMenu() {
    menuOpen = !menuOpen;
    if (menuOpen) {
      const page = pageCandidate();
      if (page && formats.url === page.url && formats.status === "error") loadFormats(page.url, true);
      renderMenu();
    }
    menu.classList.toggle("open", menuOpen);
    clearTimeout(hideTimer);
  }

  function showFor(video) {
    currentVideo = video;
    clearTimeout(hideTimer);
    if (!refreshPanel()) return;
    position();
    panel.style.display = "block";
  }

  function position() {
    if (!currentVideo) return;
    const r = currentVideo.getBoundingClientRect();
    const left = Math.min(Math.max(r.right - PANEL_W - 12, r.left + 8), window.innerWidth - PANEL_W - 8);
    const top = Math.min(Math.max(r.top + 12, 8), window.innerHeight - 60);
    panel.style.left = `${Math.round(left)}px`;
    panel.style.top = `${Math.round(top)}px`;
  }

  function scheduleHide() {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => { if (!menuOpen) hideNow(); }, 700);
  }

  function hideNow() {
    clearTimeout(hideTimer);
    menuOpen = false;
    if (menu) menu.classList.remove("open");
    if (panel) panel.style.display = "none";
    currentVideo = null;
  }

  function showToast(text, ok) {
    if (!toast) return;
    toast.textContent = text;
    toast.style.background = ok ? "rgba(22,101,52,.95)" : "rgba(153,27,27,.95)";
    toast.style.left = panel.style.left;
    toast.style.top = `${parseInt(panel.style.top || "0", 10) + 44}px`;
    toast.style.display = "block";
    setTimeout(() => { toast.style.display = "none"; }, 2500);
  }

  function sendCandidate(c) {
    try {
      chrome.runtime.sendMessage({ type: "send", url: c.url, referer: location.href, filename: c.filename || "",
        mode: c.mode || "auto", preset: c.preset || null }, (res) => {
        const ok = !!(res && res.ok);
        showToast(ok ? "Sent to ADM" : "ADM could not be started", ok);
      });
    } catch (e) {
      showToast("Extension was reloaded; refresh the page", false);
    }
    menuOpen = false;
    menu.classList.remove("open");
  }

  // ---------------------------------------------------------------- video tracking + hover
  // Streaming services that encrypt their video (DRM). The browser decrypts it inside a locked player, so there is
  // nothing a download manager could save; the panel says so instead of staying silent.
  const DRM_HOSTS = /(^|\.)(netflix\.com|primevideo\.com|disneyplus\.com|hulu\.com|max\.com|hbomax\.com|peacocktv\.com|paramountplus\.com|tv\.apple\.com|spotify\.com|crunchyroll\.com|hotstar\.com|sonyliv\.com|zee5\.com)$/i;
  let protectedMode = false;

  function hostOf(url) {
    try { return new URL(url).hostname; } catch (e) { return ""; }
  }

  function isProtected(video) {
    if (video && (video.mediaKeys || video.dataset.admEncrypted === "1")) return true;
    if (DRM_HOSTS.test(location.hostname)) return true;
    return !!(ctx && ctx.tabUrl && DRM_HOSTS.test(hostOf(ctx.tabUrl)));
  }

  function scan() {
    for (const v of document.querySelectorAll("video")) {
      if (!videos.has(v)) {
        videos.add(v);
        v.addEventListener("encrypted", () => { v.dataset.admEncrypted = "1"; }, { passive: true });
      }
    }
  }

  function videoAt(x, y) {
    for (const v of videos) {
      if (!v.isConnected) { videos.delete(v); continue; }
      if (dismissed.has(v)) continue;
      const r = v.getBoundingClientRect();
      if (r.width < MIN_W || r.height < MIN_H) continue;
      if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return v;
    }
    return null;
  }

  // Feeds scroll the next video under a still pointer (wheel, arrow keys), which fires no mousemove: follow it.
  function retarget(x, y) {
    const v = videoAt(x, y);
    if (v && v !== currentVideo) showFor(v);
  }

  function onScroll() {
    if (!currentVideo) return;
    position();
    if (menuOpen) return;
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(() => {
      if (!currentVideo || menuOpen) return;
      const v = videoAt(lastX, lastY);
      if (v) { if (v !== currentVideo) showFor(v); } else scheduleHide();
    }, 150);
  }

  function onMove(e) {
    lastX = e.clientX;
    lastY = e.clientY;
    const now = Date.now();
    if (now - lastMove < 80) return;
    lastMove = now;
    if (menuOpen) return;
    if (panel.style.display === "block") {
      const pr = panel.getBoundingClientRect();
      if (e.clientX >= pr.left && e.clientX <= pr.right && e.clientY >= pr.top && e.clientY <= pr.bottom) return;
    }
    const v = videoAt(e.clientX, e.clientY);
    if (v) {
      if (v !== currentVideo || panel.style.display !== "block") showFor(v);
      else clearTimeout(hideTimer);
    } else if (panel.style.display === "block") {
      scheduleHide();
    }
  }

  function refreshContext() {
    try {
      chrome.runtime.sendMessage({ type: "getContext" }, (res) => {
        if (chrome.runtime.lastError || !res) return;
        ctx = res;
        media = res.media || [];
        formats = { url: "", status: "idle", title: "", qualities: [], error: "" };
        if (panel && panel.style.display === "block") refreshPanel();
      });
    } catch (e) { /* extension reloaded */ }
  }

  function init(res) {
    ctx = res;
    media = res.media || [];
    buildUI();
    scan();
    const mo = new MutationObserver(() => {
      if (mo._t) return;
      mo._t = setTimeout(() => { mo._t = null; scan(); }, 300);
    });
    mo.observe(document.documentElement, { childList: true, subtree: true });
    document.addEventListener("mousemove", onMove, { passive: true, capture: true });
    document.addEventListener("mousedown", (e) => { if (menuOpen && !e.composedPath().includes(host)) hideNow(); }, true);
    window.addEventListener("scroll", onScroll, { passive: true, capture: true });
    window.addEventListener("resize", () => { if (currentVideo) position(); }, { passive: true });
    document.addEventListener("fullscreenchange", hideNow);
    setInterval(() => {
      if (location.href !== lastHref) { lastHref = location.href; media = []; refreshContext(); }
    }, 1500);
    try {
      chrome.runtime.onMessage.addListener((msg) => {
        if (msg && msg.type === "mediaList") {
          media = msg.items || [];
          if (msg.navigated) { lastHref = location.href; refreshContext(); }
          if (panel.style.display === "block") refreshPanel();
        }
      });
    } catch (e) { /* ignore */ }
  }

  // Site grabber support: hand every link / media element of this frame to the background script.
  function collectLinks() {
    const out = [];
    const push = (url, kind, text) => {
      if (url && /^(https?:|magnet:)/i.test(url) && out.length < 5000) out.push({ url, kind, text: (text || "").trim().slice(0, 120) });
    };
    for (const a of document.querySelectorAll("a[href]")) push(a.href, "link", a.textContent || a.title);
    for (const img of document.querySelectorAll("img[src]")) push(img.currentSrc || img.src, "image", img.alt);
    for (const v of document.querySelectorAll("video, audio")) {
      push(v.currentSrc || v.src, v.tagName.toLowerCase(), "");
      for (const s of v.querySelectorAll("source[src]")) push(s.src, v.tagName.toLowerCase(), "");
    }
    return { title: document.title || "", links: out };
  }
  try {
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (msg && msg.type === "collectLinks" && window.top === window) {
        sendResponse(collectLinks());
        return true;
      }
      return false;
    });
  } catch (e) { /* ignore */ }

  // ---------------------------------------------------------------- magnet links and .torrent links
  // Always on (the video button can be turned off separately). Only a real mouse click counts: a click a script
  // makes has detail 0 and goes on to the browser, which asks before opening another program.
  let catchTorrents = true;
  try {
    chrome.storage.sync.get({ torrents: true }, (s) => { catchTorrents = !s || s.torrents !== false; });
    chrome.storage.onChanged.addListener((changes) => {
      if (changes.torrents) catchTorrents = changes.torrents.newValue !== false;
    });
  } catch (e) { /* extension context gone */ }

  function torrentNotice(text, ok) {
    const n = document.createElement("div");
    n.textContent = text;
    n.style.cssText = "all:initial;position:fixed;right:16px;bottom:16px;z-index:2147483647;padding:9px 13px;border-radius:8px;"
      + "font:13px system-ui,'Segoe UI',sans-serif;color:#fff;box-shadow:0 4px 14px rgba(0,0,0,.35);background:"
      + (ok ? "rgba(22,101,52,.95)" : "rgba(153,27,27,.95)");
    document.documentElement.appendChild(n);
    setTimeout(() => n.remove(), 3000);
  }

  document.addEventListener("click", (e) => {
    if (!catchTorrents || !e.isTrusted || e.detail < 1 || e.button !== 0 || e.defaultPrevented
        || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
    const link = e.composedPath().find((n) => n.tagName === "A" && n.href);
    if (!link) return;
    const href = link.href;
    let isTorrentFile = false;
    try {
      isTorrentFile = /^https?:$/.test(new URL(href).protocol) && /\.torrent$/i.test(new URL(href).pathname);
    } catch (err) { /* not an address */ }
    if (!isTorrentFile && !/^magnet:/i.test(href)) return;
    e.preventDefault();
    e.stopPropagation();
    try {
      chrome.runtime.sendMessage({ type: "send", url: href, referer: location.href, mode: "auto" }, (res) => {
        if (!chrome.runtime.lastError && res && res.ok) {
          torrentNotice("Sent to ADM", true);
        } else {
          location.href = href;      // hand it back: the browser opens it with the system's program
        }
      });
    } catch (err) {
      location.href = href;          // the add-on was reloaded after this page opened
    }
  }, true);

  try {
    chrome.runtime.sendMessage({ type: "getContext" }, (res) => {
      if (chrome.runtime.lastError || !res || res.overlay === false) return;
      if (document.body) init(res);
      else document.addEventListener("DOMContentLoaded", () => init(res), { once: true });
    });
  } catch (e) { /* extension context gone */ }
})();
